﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Snake2
{
    class Field
    {
        private readonly Coord coord;
        private IThing thing;

        public Field(Coord coord)
        {
            this.coord = coord;
            thing = null;
        }

        public Coord GetCoord()
        {
            return coord;
        }

        public void Accept(Snake who)
        {
            if (thing == null)
            {
                who.MoveTo(this);
            }
            else
            {
                thing.Collide(who);
            }
        }

        public void SetThing(IThing newThing)
        {
            thing = newThing;
        }

        public void RemoveThing()
        {
            thing = null;
        }
    }
}
