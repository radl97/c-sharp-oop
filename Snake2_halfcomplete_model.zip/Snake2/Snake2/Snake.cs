﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Snake2
{
    class Snake
    {
        // Milyen mezőkön van rajta a kígyó.
        // Head - last; Tail - first.
        private LinkedList<Field> sections;
        private Game game;
        private bool dead;

        public Snake(Game game)
        {
            this.game = game;
            dead = false;
            sections = new LinkedList<Field>();

            // Odacsalunk egy kezdő felállást.
            Coord coord = new Coord(4, 4);
            sections.AddLast(game.GetField(coord));

            coord = coord.GetAdjacentCoord(Direction.Right);
            sections.AddLast(game.GetField(coord));

            coord = coord.GetAdjacentCoord(Direction.Down);
            sections.AddLast(game.GetField(coord));
        }

        public void Move()
        {
            if (dead)
            {
                return;
            }
            Coord head = sections.Last.Value.GetCoord();
            Coord newHead = head.GetAdjacentCoord(Direction.Down);
            game.MoveTo(this, newHead);
            // game.GetField(newHead).GetThing().Collide(this);
            // Law of Demeter: ezt a láncot nem szeretjük
            //sections.AddLast(game.GetField(newHead));

            Field f = sections.First.Value;
            f.RemoveThing();
            sections.RemoveFirst();
            
        }

        // Akkor hívják meg, ha már fixen oda tudunk menni
        public void MoveTo(Field field)
        {
            field.SetThing(new Wall()); // 
            sections.AddLast(field);
        }

        public void Die()
        {
            dead = true;
        }
    }
}
