﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Snake2
{
    class Drawer
    {
        private Game game;

        public Drawer(Game game)
        {
            this.game = game;
        }
        public void Draw()
        {
            Console.Clear();
            // pálya teteje
            Console.Write("#"); // bal felső sarok
            for (int j = 0; j < 10; j++)
            {
                Console.Write("##"); // felső szél
            }
            Console.WriteLine("#"); // jobb felső sarok

            // maga a pálya, bal és jobb szélekkel
            for (int i = 0; i < 10; i++)
            {
                Console.Write("#"); // bal szél
                for (int j = 0; j < 10; j++)
                {
                    //?? game.GetField(new Coord(i, j));
                    Console.Write("  ");
                }
                Console.WriteLine("#"); // jobb szél
            }

            // pálya alja
            Console.Write("#"); // bal alsó sarok
            for (int j = 0; j < 10; j++)
            {
                Console.Write("##"); // alsó szél
            }
            Console.WriteLine("#"); // jobb alsó sarok
        }
    }
}
