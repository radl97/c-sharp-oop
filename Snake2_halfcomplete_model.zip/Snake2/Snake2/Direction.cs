﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Snake2
{
    enum Direction
    {
        Up, Right, Down, Left
    }
}
