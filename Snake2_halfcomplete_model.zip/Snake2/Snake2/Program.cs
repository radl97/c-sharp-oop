﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Snake2
{
    class Program
    {
        public Program()
        {
            // Eseményvezérelt programozás: több esemény lehet,
            // ezek bekövetkeztekor reagálunk.
            Game game = new Game();
            Snake snake = new Snake(game);
            game.AddSnake(snake); // Ez még problémás picit.
            Controller controller = new Controller(game);
            Drawer drawer = new Drawer(game);
            while (game.IsRunning())
            {
                drawer.Draw();
                if (Console.KeyAvailable)
                {
                    char key = Console.ReadKey().KeyChar;
                    controller.OnKeyPress(key);
                }
                else
                {
                    // Nem feltétlen 300ms-enként fut le, lehet picit több.
                    Thread.Sleep(300); // milliszekundum
                    controller.Tick();
                }
            }
        }
        static void Main(string[] args)
        {
            new Program();
        }
    }
}
