﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Snake2
{
    class Snake
    {
        // Milyen mezőkön van rajta a kígyó.
        // Head - last; Tail - first.
        private LinkedList<Field> fields;
        private Game game;

        public Snake(Game game)
        {
            this.game = game;
            fields = new LinkedList<Field>();

            // Odacsalunk egy kezdő felállást.
            Coord coord = new Coord(4, 4);
            fields.AddLast(game.GetField(coord));

            coord = coord.GetAdjacentCoord(Direction.Right);
            fields.AddLast(game.GetField(coord));

            coord = coord.GetAdjacentCoord(Direction.Down);
            fields.AddLast(game.GetField(coord));
        }

        public void Move()
        {
            Coord head = fields.Last.Value.GetCoord();
            Coord newHead = head.GetAdjacentCoord(Direction.Down);
            fields.AddLast(game.GetField(newHead));
            fields.RemoveFirst();
        }
    }
}
