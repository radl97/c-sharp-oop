﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Snake2
{
    class Field
    {
        private readonly Coord coord;
        private readonly IFieldContent content;
        // + mi van ott...

        public Field(Coord coord)
        {
            this.coord = coord;
            content = new FreeField();
        }

        public Coord GetCoord()
        {
            return coord;
        }
    }
}
