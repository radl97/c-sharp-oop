﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Snake2
{
    class Coord
    {
        // y lefelé, x jobbra nő
        private readonly int x, y;
        public Coord(int x, int y)
        {
            this.x = x;
            this.y = y;
        }
        public int GetX()
        {
            return x;
        }
        public int GetY()
        {
            return y;
        }
        public Coord GetAdjacentCoord(Direction direction)
        {
            if (direction == Direction.Up)
            {
                return new Coord(x, y - 1);
            }
            else if (direction == Direction.Left)
            {
                return new Coord(x - 1, y);
            }
            else if (direction == Direction.Down)
            {
                return new Coord(x, y + 1);
            }
            else if (direction == Direction.Right)
            {
                return new Coord(x + 1, y);
            }
            // Hiba?!
            // Kivételt dobunk.
            // ... Nem fogjuk lekezelni, általában illik.
            throw new ArgumentException();
        }
    }
}
