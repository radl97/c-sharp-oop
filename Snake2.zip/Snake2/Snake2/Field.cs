﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Snake2
{
    class Field
    {
        private readonly Coord coord;
        // + mi van ott...

        public Field(Coord coord)
        {
            this.coord = coord;
        }

        public Coord GetCoord()
        {
            return coord;
        }
    }
}
