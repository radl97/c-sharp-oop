﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Snake2
{
    class Game
    {
        private bool running;
        private List<Snake> snakes;
        private Field[,] fields;

        public Game()
        {
            running = true;
            snakes = new List<Snake>();
            fields = new Field[10, 10];
            for (int x = 0; x < 10; x++)
            {
                for (int y = 0; y < 10; y++)
                {
                    fields[x, y] = new Field(new Coord(x, y));
                }
            }
        }

        public void End()
        {
            running = false;
        }

        public bool isRunning()
        {
            return running;
        }

        public void Tick()
        {
            // Snake-ek mozgatása itt lesz...
            foreach (Snake s in snakes)
            {
                s.Move();
            }
        }

        public void AddSnake(Snake snake)
        {
            snakes.Add(snake);
        }

        public Field GetField(Coord coord)
        {
            return fields[coord.GetX(), coord.GetY()];
        }
    }
}
